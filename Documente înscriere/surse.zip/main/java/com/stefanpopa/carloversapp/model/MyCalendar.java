package com.stefanpopa.carloversapp.model;

public class MyCalendar {
    private long timeInMillis;

    public MyCalendar() {

    }

    public long getTimeInMillis() {
        return timeInMillis;
    }

    public void setTimeInMillis(long timeInMillis) {
        this.timeInMillis = timeInMillis;
    }
}
